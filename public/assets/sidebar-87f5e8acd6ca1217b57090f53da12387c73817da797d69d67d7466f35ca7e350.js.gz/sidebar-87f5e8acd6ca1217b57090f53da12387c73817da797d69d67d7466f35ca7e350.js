  $(".nav_trigger").click(function() {
  $("body").toggleClass("show_sidebar");
  $(".nav_trigger .fa").toggleClass("fa-times"); 
    });



